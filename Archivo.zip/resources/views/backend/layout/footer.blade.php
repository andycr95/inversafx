<footer class="main-footer">
    <div class="footer-left">
        {{@$general->copyright}}
    </div>

</footer>
