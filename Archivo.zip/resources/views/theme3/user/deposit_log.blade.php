@extends(template().'layout.master2')

@section('content2')

    @include('theme3.user.ajax.deposit_log')

@endsection
